MAJOR = 0
MINOR = 3
MICRO = 1
PATCH = 3

__version__ = '{}.{}.{}.{}'.format(MAJOR, MINOR, MICRO, PATCH)
